//
//  DBAccess.swift
//  IOSDevConf
//
//  Created by Chris Price on 06/04/2015.
//  Copyright (c) 2015 Chris Price. All rights reserved.
//

import Foundation
import SQLite3

private let _hiddenSharedInstance = DBAccess()

class DBAccess{
    
    static var readingListVC : ReadingListVC? = nil
    
    
    class var sharedInstance: DBAccess{
        return _hiddenSharedInstance;
    }
    
    var mySQLDB: OpaquePointer? = nil  // This is a pointer to the database
 
    init(){
        openSQLDB()
    }
    
    func openSQLDB(){
        //Set up path to DB, and open
        let bundle = Bundle.main
        guard let defaultDBPath = bundle.path( forResource: "conf", ofType: "sql")
            else {
                assertionFailure( "Couldn't find database path")
                return
        }
        guard sqlite3_open_v2( defaultDBPath, &mySQLDB, SQLITE_OPEN_READONLY, nil) == SQLITE_OK
            else {
                assertionFailure( "Couldn't open database")
                return
        }
    }

    func stringAtField(_ statementPointer: OpaquePointer, fieldIndex: Int ) -> String {
        var answer = "Error - DBAccess failed"
        if let rawString = sqlite3_column_text(statementPointer, Int32(fieldIndex) ) {
            answer = String(cString: rawString)
        }
 
        return answer
    }

       //run a SQLlite query on the speakers table to pull the data and store it into an array based
      //on the day passed to the function
    func getSession(day: String) -> [Session] {
        var mySession: Session!

        let query = "SELECT * FROM sessions WHERE sessionDate='\(day)'"
        
        var statement: OpaquePointer? = nil  // Pointer for sql to track returns
        
        var sessionArray: [Session] = []
        
        if sqlite3_prepare_v2( mySQLDB, query, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let sessionID = stringAtField(statement!, fieldIndex: 0)
                let title = stringAtField(statement!, fieldIndex: 1)
                 let content = stringAtField(statement!, fieldIndex: 2)
                 let locationID = stringAtField(statement!, fieldIndex: 3)
                 let sessionDate = stringAtField(statement!, fieldIndex: 4)
                 let sessionOrder = stringAtField(statement!, fieldIndex: 5)
                 let timeStart = stringAtField(statement!, fieldIndex: 6)
                 let timeEnd = stringAtField(statement!, fieldIndex: 7)
                 let sessionType = stringAtField(statement!, fieldIndex: 8)
                 let speakerID = stringAtField(statement!, fieldIndex: 9)
            
                mySession = Session(sessionID: sessionID, title: title, content:content, locationID: locationID, sessionDate: sessionDate, sessionOrder: sessionOrder, timeStart: timeStart, timeEnd: timeEnd, sessionType: sessionType, speakerID: speakerID)
                
                sessionArray.append(mySession)
               
            }

        }
        sqlite3_finalize(statement)
        return sessionArray
    }
    
       //run a SQLlite query on the sessiona table to pull the data and store it into an array
    func getAllSessions() -> [Session] {
        var mySession: Session!
        
        let query = "SELECT * FROM sessions"
        
        var statement: OpaquePointer? = nil  // Pointer for sql to track returns
        
        var sessionArray: [Session] = []
        
        if sqlite3_prepare_v2( mySQLDB, query, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let sessionID = stringAtField(statement!, fieldIndex: 0)
                let title = stringAtField(statement!, fieldIndex: 1)
                let content = stringAtField(statement!, fieldIndex: 2)
                let locationID = stringAtField(statement!, fieldIndex: 3)
                let sessionDate = stringAtField(statement!, fieldIndex: 4)
                let sessionOrder = stringAtField(statement!, fieldIndex: 5)
                let timeStart = stringAtField(statement!, fieldIndex: 6)
                let timeEnd = stringAtField(statement!, fieldIndex: 7)
                let sessionType = stringAtField(statement!, fieldIndex: 8)
                let speakerID = stringAtField(statement!, fieldIndex: 9)
                
                mySession = Session(sessionID: sessionID, title: title, content:content, locationID: locationID, sessionDate: sessionDate, sessionOrder: sessionOrder, timeStart: timeStart, timeEnd: timeEnd, sessionType: sessionType, speakerID: speakerID)
                
                sessionArray.append(mySession)
                
            }
            
        }
        sqlite3_finalize(statement)
        return sessionArray
    }
    
    //run a SQLlite query on the speakers table to pull the data and store it into an array
    func getSpeakers() -> [Speakers] {
        var speakers: Speakers!
        let speakerQuery = "SELECT * FROM speakers;"
        
        var statement: OpaquePointer? = nil
        
        var speakerArray: [Speakers] = []
        
        if sqlite3_prepare_v2( mySQLDB, speakerQuery, -1, &statement, nil) == SQLITE_OK{
            while sqlite3_step(statement) == SQLITE_ROW {
                let id = stringAtField(statement!, fieldIndex: 0)
                let name = stringAtField(statement!, fieldIndex: 1)
                let biography = stringAtField(statement!, fieldIndex: 2)
                let twitter = stringAtField(statement!, fieldIndex: 3)
                
                speakers = Speakers(id: id, name: name, biography: biography, twitter: twitter)
                
                speakerArray.append(speakers)
            }
        }
        sqlite3_finalize(statement)
        return speakerArray
    }
    
    //Run a SQLlite query on the locations table and store it into an array
    func getLocations() -> [Location] {
        var location: Location!
        let speakerQuery = "SELECT * FROM locations;"
        
        var statement: OpaquePointer? = nil
        var locationArray: [Location] = []
        
        if sqlite3_prepare_v2( mySQLDB, speakerQuery, -1, &statement, nil) == SQLITE_OK{
            while sqlite3_step(statement) == SQLITE_ROW{
                let id = stringAtField(statement!, fieldIndex: 0)
                let name = stringAtField(statement!, fieldIndex: 1)
                let latitude = stringAtField(statement!, fieldIndex: 2)
                let latitudeConv = Double(latitude)
                let longitude = stringAtField(statement!, fieldIndex: 3)
                let longitudeConv = Double(longitude)
                let description = stringAtField(statement!, fieldIndex: 4)
                
                location = Location(id: id, name:name, latitude: latitudeConv!, longitude: longitudeConv!, description:description)
                
                locationArray.append(location)
                
            }
        }
        sqlite3_finalize(statement)
        return locationArray
    }
    
    
    
    
}

    



