//  Favorites.swift
//  IOSDevConf
//
//  Created by dac78 on 26/11/2019.
//

import Foundation

struct Favorites{
    var favoritesArray = [String] ()
    
    init(favoritesArray : [String])
    {
        self.favoritesArray = favoritesArray
    }
}
