//Location.swift
//  IOSDevConf
//
//  Created by dac78 on 17/11/2019.
//

import Foundation

struct Location{
    var id: String
    var name: String
    var latitude: Double
    var longitude: Double
    var description: String
    
    init( id:String, name:String, latitude:Double, longitude: Double, description:String)
    {
        self.id = id
        self.name = name
        self.latitude = latitude
        self.longitude = longitude
        self.description = description
    }
    
}
