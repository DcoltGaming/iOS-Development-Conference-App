//  Session.swift
//  IOSDevConf


import Foundation

public struct Session{
    
    var sessionID : String
    var title: String
    var content: String
    var locationID: String
    var sessionDate: String
    var sessionOrder: String
    var timeStart: String
    var timeEnd: String
    var sessionType:String
    var speakerID: String

    
    init( sessionID: String, title: String, content: String, locationID: String, sessionDate: String, sessionOrder: String,
          timeStart: String, timeEnd: String, sessionType: String, speakerID:String){
       self.sessionID = sessionID
        self.title = title
        self.content = content
        self.locationID = locationID
        self.sessionDate = sessionDate
        self.sessionOrder = sessionOrder
        self.timeStart = timeStart
        self.timeEnd = timeEnd
        self.sessionType = sessionType
        self.speakerID = speakerID
    }
    
    
 
    
    
}
