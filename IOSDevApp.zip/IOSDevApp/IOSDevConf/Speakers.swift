//  Speakers.swift
//  SIOSDevConf
//
//  Created by dac78 on 17/11/2019.


import Foundation

struct Speakers{
    var id: String
    var name: String
    var biography: String
    var twitter:String

init( id: String, name: String, biography: String, twitter: String){
    self.id = id
    self.name = name
    self.biography = biography
    self.twitter = twitter
}

}
