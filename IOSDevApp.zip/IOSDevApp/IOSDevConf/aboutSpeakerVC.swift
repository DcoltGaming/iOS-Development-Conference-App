//  aboutSpeakerVC.swift
//  IOSDevConf
//
//  Created by dac78 on 18/11/2019.
//

import UIKit

class aboutSpeakerVC: UIViewController {

    //Assign outlets for each label
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var biographyLabel: UILabel!
    @IBOutlet weak var twitterButtonPlaceholder: UIButton!
    @IBOutlet weak var speakerImage: UIImageView!
    
    //Create stings for each label value
    var valueForNameLabel = ""
    var valueForBiographyLabel = ""
    var twitterLabel = ""
    var twitterHandle = ""
    var imageTitle = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //set the values of the label strings
        nameLabel.text = valueForNameLabel
        speakerImage.image = UIImage(named:"\(imageTitle).jpg")
        twitterHandle = "http://twitter.com/" + twitterLabel
        biographyLabel.text = valueForBiographyLabel
    }
    
    //if twitter button is pressed, direct the user to twitter.com and append the twitter handle
    @IBAction func twitterButtonWasPressed(_ sender: Any) {
   UIApplication.shared.open(URL(string: twitterHandle)! as URL, options: [:], completionHandler: nil)
    }
  
    }


