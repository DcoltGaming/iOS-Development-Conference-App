//
//  favoritesCell.swift
//  SimpleDBRead
//
//  Created by dac78 on 29/11/2019.
//  Copyright © 2019 Chris Price. All rights reserved.
//

import UIKit

class favoritesCell: UITableViewCell {
    
    
    @IBOutlet weak var sessionTitle: UILabel!
    @IBOutlet weak var sessionTime: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
