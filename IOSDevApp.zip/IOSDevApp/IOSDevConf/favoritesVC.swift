//  favoritesVC.swift
//  SimpleDBRead
//
//  Created by dac78 on 29/11/2019.
//

import UIKit

class favoritesVC: UITableViewController {
    
    //create empty arrays to store favorites, sessions, speakers and locations
    var favoritesArray: [String] = []
    var sessionsArray: [Session] = []
    var allSpeakers: [Speakers] = []
    var allLocations: [Location] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        //set the sessions, speakers and locations values
        sessionsArray = DBAccess.sharedInstance.getAllSessions()
        allSpeakers = DBAccess.sharedInstance.getSpeakers()
        allLocations = DBAccess.sharedInstance.getLocations()
    }
     //when the view controller appears, refresh the favorites and array and table data
    override func viewWillAppear(_ animated: Bool) {
        refreshFavorites()
         tableView.reloadData()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return favoritesArray.count
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Favourites"
    }
    
    //Create a cell and callSearchSession index to search the allSessions array to find the correct session based on the seected cell. The values for the labels are then set
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "favoritesCell", for: indexPath) as! favoritesCell
        let sessionIndex = searchSessionsIndex(sessionID: favoritesArray[indexPath.row], sessionsArray: sessionsArray)
        
        cell.sessionTitle.text = sessionsArray[sessionIndex!].title
        cell.sessionTime.text = sessionsArray[sessionIndex!].timeStart + " - " + sessionsArray[sessionIndex!].timeEnd
        cell.dateLabel.text = sessionsArray[sessionIndex!].sessionDate
        
        return cell
    }
    
    //pass the details to the moreDetails view controller. Same as found in ReadingListVC
    override func prepare(for segue: UIStoryboardSegue, sender: Any? ) {
        
        if segue.identifier == "moreDetailsSegue" {

            if let indexPath = self.tableView.indexPathForSelectedRow{
                
                let detailVC = segue.destination as! moreDetails
                let sessionIndex = searchSessionsIndex(sessionID: favoritesArray[indexPath.row], sessionsArray: sessionsArray)
                
                for speakers in allSpeakers {
                    if(speakers.id == sessionsArray[sessionIndex!].speakerID)
                    {
                        detailVC.valueForSpeakerLabel = speakers.name
                    }
                }
                
                for locations in allLocations {
                    if(locations.id == sessionsArray[sessionIndex!].locationID)
                    {
                        detailVC.valueForLocationLabel = locations.name
                        detailVC.longitudeValue = locations.longitude
                        detailVC.latitudeValue = locations.latitude
                    }
                }
                
                detailVC.valueForLabel = sessionsArray[sessionIndex!].title
                detailVC.valueForContentLabel = sessionsArray[sessionIndex!].content
                detailVC.valueForTimeLabel = sessionsArray[sessionIndex!].timeStart + " - " + sessionsArray[sessionIndex!].timeEnd
                detailVC.imageTitle = sessionsArray[sessionIndex!].speakerID
                detailVC.sessionID = sessionsArray[sessionIndex!].sessionID
                detailVC.sessionType = sessionsArray[sessionIndex!].sessionType
            }
        }
    }
    
    //return the int of the first index found matching the session id 
    func searchSessionsIndex(sessionID: String, sessionsArray: [Session]) -> Int? {
        return sessionsArray.firstIndex { (sess) -> Bool in
            sess.sessionID == sessionID
        }
    }
    
    //create a instance of more details and assign the array to the internal favorites array
    func refreshFavorites()
    {
        let moreDetailsTest = moreDetails()
        moreDetailsTest.loadFavorites()
        favoritesArray = moreDetailsTest.favoritesArray
    }
}



