//moreDetails.swift
//  IOSDevConf
//
//  Created by dac78 on 12/11/2019.
//  Copyright © 2019 dac78. All rights reserved.
//

import UIKit
import MapKit
import Swift

class moreDetails: UIViewController, UINavigationControllerDelegate {

    //Create @IBOutlet for each label
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var speakerLabel: UILabel!
    @IBOutlet weak var contentLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var speakerImage: UIImageView!
    @IBOutlet weak var speakerInformationButton: UIButton!
    @IBOutlet weak var speakerTitleLabel: UILabel!
    @IBOutlet weak var favoritesButton: UIButton!
    
    //Create strings for each label value
    var valueForLabel  = ""
    var valueForLocationLabel = ""
    var valueForSpeakerLabel = ""
    var valueForContentLabel = ""
    var valueForTimeLabel = ""
    var imageTitle = ""
    var longitudeValue = 0.0
    var latitudeValue = 0.0
    var sessionID = ""
    var sessionType = ""
    
    //Create a empty string array to store favorites
    var favoritesArray: [String] = []
    
    // Create the info button
    @objc let infoButton = UIButton(type: .infoLight)
    
    override func viewDidLoad() {
     super.viewDidLoad()
        
        navigationController?.delegate = self
        
        //set the back button icon and append the title "Sessions"
        let backItem = UIBarButtonItem(title: "Details", style: .plain, target: nil, action: nil)
        navigationItem.backBarButtonItem = backItem
        
        //set the text values for labels
        timeLabel.text = valueForTimeLabel
        titleLabel.text = valueForLabel
        locationLabel.text = valueForLocationLabel
        speakerLabel.text = valueForSpeakerLabel
        contentLabel.text = valueForContentLabel
        speakerImage.image = UIImage(named:"\(imageTitle).jpg")
        
        //if the session is not a talk or a workshop then favorites button will not be displayed
        if( sessionType != "talk" && sessionType != "workshop")
        {
            favoritesButton.isHidden = true
        }
        
        //if the session has no speaker then the speaker buttons will not appear
        if( valueForSpeakerLabel == "")
        {
            speakerInformationButton.isHidden = true
            speakerLabel.text = "Session has no speaker"
            speakerTitleLabel.isHidden = true
        }
        
        loadFavorites()
        
        if(favoritesArray.contains(sessionID))
        {
            favoritesButton.setImage(#imageLiteral(resourceName: "favoritesFill.png"), for: .normal)
        }
        else if (!favoritesArray.contains(sessionID)){
            favoritesButton.setImage(#imageLiteral(resourceName: "Favorites icon 1"), for: .normal)
        }
  }
    
    
    //Create a segue for speakerDetails
    override func prepare(for segue: UIStoryboardSegue, sender: Any?  )
    {
        if segue.identifier == "speakerDetailsSegue" {
            var allSpeakers: [Speakers] = [] //create a empty array of Speakers
            allSpeakers = DBAccess.sharedInstance.getSpeakers()//pull and store speaker data
       
            let speakerInformationVC = segue.destination as! aboutSpeakerVC //set destination to aboutSpeakerVC
            
            speakerInformationVC.valueForNameLabel = valueForSpeakerLabel //set name label
            
            //loop through speakers, when the correct one is found set the twitter and biography
            for speakers in allSpeakers {
                if(speakers.name == speakerInformationVC.valueForNameLabel)
                {
                    speakerInformationVC.twitterLabel = speakers.twitter
                    speakerInformationVC.valueForBiographyLabel = speakers.biography
                }
            }
            
            speakerInformationVC.imageTitle = imageTitle
        }
        
        //if segue is to favorites, set the favorites array
        if segue.identifier == "favoritesSegue"
        {
            let favoritesVC = segue.destination as! favoritesVC
            
            favoritesVC.favoritesArray = favoritesArray
        }
        
}

    //Pass the  longitude and latitude coordiantes to the map
    @IBAction func BttnTest(_ sender: Any) {
        let regionDistance:CLLocationDistance = 10000
        let coordinates = CLLocationCoordinate2DMake(latitudeValue, longitudeValue)
        let regionSpan = MKCoordinateRegion(center: coordinates, latitudinalMeters: regionDistance, longitudinalMeters: regionDistance)
        let options = [
            MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),
            MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)
        ]
        let placemark = MKPlacemark(coordinate: coordinates, addressDictionary: nil)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = locationLabel.text
        mapItem.openInMaps(launchOptions: options)
        
    }
    
    //when the favorites button is clicked then load favorites. If the array is empty, add the value to position [0], else add the value to the next position. If the value is already in the array then it will be removed
    @IBAction func favoritesClick(_ sender: Any) {
        loadFavorites()
        
        if(!favoritesArray.isEmpty) {
            if(favoritesArray.contains(sessionID)){
                favoritesArray.remove(at: favoritesArray.firstIndex(of: sessionID)!)
                favoritesButton.setImage(#imageLiteral(resourceName: "Favorites icon 1"), for: .normal)
                saveFavorites()
                return
            }
            else if(!favoritesArray.contains(sessionID))
            {
                let arrayCount = favoritesArray.count
                
                if(arrayCount > 1 )
                {
                favoritesArray.insert(sessionID, at: favoritesArray.count)
                }
                else if (arrayCount == 1)
                {
                     favoritesArray.insert(sessionID, at: 1	)
                     favoritesButton.setImage(#imageLiteral(resourceName: "favoritesFill"), for: .normal)
                }
            }
        }
        
        if(favoritesArray.isEmpty)
        {
            favoritesArray.append(sessionID)
            favoritesButton.setImage(#imageLiteral(resourceName: "favoritesFill.png"), for: .normal)
        }
    
       print(favoritesArray.count)
       
      saveFavorites()
    }
    
    //Credit @Chris Price
    //create a Favorites.plist file and store the array to this
    func saveFavorites(){
        let favouritesURL  =
            urlToFileInDocuments("Favourites.plist")
        let encoder = PropertyListEncoder()
        encoder.outputFormat = .xml
        if let data = try? encoder.encode(favoritesArray) {
            //Write the data to backing store.
            try? data.write(to: favouritesURL,
                            options: .noFileProtection)
        }
    }
    
    func urlToFileInDocuments( _ fileName: String ) -> URL {
        let docDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileURL = docDirectory.appendingPathComponent(fileName)
        print(fileURL)
        return fileURL
    }
    
    func fileExistsInDocuments( _ fileName: String ) -> Bool {
        let fileManager = FileManager.default
        let dirPaths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let docsDir = dirPaths[0]
        let filepathName = docsDir + "/\(fileName)"
        return fileManager.fileExists(atPath: filepathName)
    }
    
    
    func loadFavorites(){
        // Load present position, or if starting then set defaults
        if fileExistsInDocuments("Favourites.plist") {
            let settingsURL =
                urlToFileInDocuments("Favourites.plist")
            if let dataFromFile = try? Data(contentsOf: settingsURL) {
                // Decode the plist back to state of program
                let decoder = PropertyListDecoder()
                if let loadedArray = try? decoder.decode([String].self, from: dataFromFile) {
                    favoritesArray = loadedArray
                }
            }
        } else {
            // already initialised with starting values - just save
            saveFavorites()
        }
    }
    
    //------------------------------------------------------------------------------------------
    
    //every time the view controller is loaded the favorites array should be loaded
    func navigationController(_ navigationController: UINavigationController, willShow viewController: UIViewController, animated: Bool) {
        (viewController as? ReadingListVC)?.favorites = favoritesArray
    }
    
    }


