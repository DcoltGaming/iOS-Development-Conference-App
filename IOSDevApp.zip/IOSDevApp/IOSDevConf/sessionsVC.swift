//sessionsVC.swift


import UIKit
var daySelected = 0
class ReadingListVC: UITableViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var dayConverter = ""
   
     let pickerData = ["Select Day","10-12-2019","11-12-2019","12-12-2019", "13-12-2019"]
   
    //set the number of columns in the pickerView
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    //Set the number if rows in the picker - number is dependent on the amount of days (5)
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    //Construct empty arrays to store the data from the tables
    var allSessions: [Session] = []
    var allSpeakers: [Speakers] = []
    var allLocations: [Location] = []
   
    //create a empty array to store the data for the favorites
    var favorites: [String] = []
    
    //connect the picker to the storyboard
    @IBOutlet weak var dayPicker: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
         refreshFavorites()  //run the refresh favorites script to update the favorites array
       allSpeakers = DBAccess.sharedInstance.getSpeakers() //pull data for the speakers
       allLocations = DBAccess.sharedInstance.getLocations() //pull data for locations
        //set the picker delegate and data source
      self.dayPicker.delegate = self
      self.dayPicker.dataSource = self
        
    }
    
    //set the row title to be the row value for what is selected
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    //Create a instance of more details then load the favorites file and update the array
    func refreshFavorites()
    {
        let moreDetailsTest = moreDetails()
        moreDetailsTest.loadFavorites()
        favorites = moreDetailsTest.favoritesArray
    }
    
    //when a row is picker view is selected, run the day selector, load allSessions passing the day
    // and reload the data in the table
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        daySelector(daySelection: row)
        allSessions = DBAccess.sharedInstance.getSession(day: dayConverter)
        self.tableView.reloadData()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allSessions.count
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return dayConverter
       
    }
    
    //take a int value, run it through a switch statement and set dayConverter tothe corresponding day
    func daySelector(daySelection: Int)
    {
        switch daySelection {
        case 1: dayConverter = "2019-12-10"
        case 2: dayConverter = "2019-12-11"
        case 3: dayConverter = "2019-12-12"
        case 4: dayConverter = "2019-12-13"
        default:
            dayConverter = ""
        }
    }
    
    //Create a cell and set the title and start cells to the value of the corresponding allSessions index
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = self.tableView.dequeueReusableCell(withIdentifier: "ReadingCell", for: indexPath) as! sessionCell
        cell.TitleCell.text = allSessions[indexPath.row].title
        cell.StartTime.text = allSessions[indexPath.row].timeStart
        return cell
    }
    
    //When the user clicks on a row this segue should be run
    override func prepare(for segue: UIStoryboardSegue, sender: Any? ) {
        
        if segue.identifier == "moreDetailsSegue" {
            
            if let indexPath = self.tableView.indexPathForSelectedRow{ //set indexPath to be the value of the selected row
                
                let detailVC = segue.destination as! moreDetails //set segue destinations to the moreDetails view controller
                
                //set the speakers name to the speaker label value
                for speakers in allSpeakers {
                    if(speakers.id == allSessions[indexPath.row].speakerID)
                    {
                        detailVC.valueForSpeakerLabel = speakers.name
                    }
                }
                
                //loop through locations and set the location name, longitude and latitude
                for locations in allLocations {
                    if(locations.id == allSessions[indexPath.row].locationID)
                    {
                        detailVC.valueForLocationLabel = locations.name
                        detailVC.longitudeValue = locations.longitude
                        detailVC.latitudeValue = locations.latitude
                    }
                }
                
                //set the label values for the more details view controller
                detailVC.valueForLabel = allSessions[indexPath.row].title
                detailVC.valueForContentLabel = allSessions[indexPath.row].content
                detailVC.valueForTimeLabel = allSessions[indexPath.row].timeStart + " - " + allSessions[indexPath.row].timeEnd
                detailVC.imageTitle = allSessions[indexPath.row].speakerID
                detailVC.sessionID = allSessions[indexPath.row].sessionID
                detailVC.sessionType = allSessions[indexPath.row].sessionType
            }
        }
        
        //if the user selectes favorites, pass the favorites array
        if segue.identifier == "favoritesSegue" {
            let favoriteVC = segue.destination as! favoritesVC
            favoriteVC.favoritesArray = favorites
        }
        
       
        
    }
                
}





    

        
    
       
    

