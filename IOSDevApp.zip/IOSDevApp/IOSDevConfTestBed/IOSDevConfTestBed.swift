//
//  SimpleDBReadTestBed.swift
//  SimpleDBReadTestBed
//
//  Created by dac78 on 01/12/2019.
//  Copyright © 2019 Chris Price. All rights reserved.
//

import XCTest

class SimpleDBReadTestBed: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    
    //--------------------------------DBAccess Tests-------------------------------------
    func testGetSession(){
        var sessions:[Session] = DBAccess.sharedInstance.getSession(day: "2019-12-10")
        XCTAssert(sessions[0].sessionID == "arkit")
    }
    
    func testGetSpeakers(){
        var speakers:[Speakers] = DBAccess.sharedInstance.getSpeakers()
        XCTAssert(speakers[0].id == "AdamRush")
    }
    
    func testDanielTull(){
        var speakers:[Speakers] = DBAccess.sharedInstance.getSpeakers()
        XCTAssert(speakers[7].id == "DanielTull")
    }
    
    func testGetLocations(){
        var locations:[Location] = DBAccess.sharedInstance.getLocations()
        XCTAssert(locations[0].id == "b23")
    }
    
    //------------------------------------------------------------------------------------

    //--------------------------------favoritesVC Tests-------------------------------------
    func testFindFavoritesIndex()
    {
        var sessionsArray: [Session] = []
        sessionsArray = DBAccess.sharedInstance.getAllSessions()
        let favorites = favoritesVC()
        let value = favorites.searchSessionsIndex(sessionID: "arkit", sessionsArray: sessionsArray)
        XCTAssert(value == 0)
        
    }
    //------------------------------------------------------------------------------------
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
